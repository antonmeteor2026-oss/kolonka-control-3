package com.kolonka.control;

import android.app.Activity;
import android.content.Intent;
import android.media.audiofx.Equalizer;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private Equalizer equalizer;
    private LinearLayout root;
    private final int bg = Color.rgb(5, 10, 22);
    private final int panel = Color.rgb(20, 29, 53);
    private final int blue = Color.rgb(35, 135, 255);
    private final int white = Color.rgb(238, 244, 255);
    private final String[] bands = {"60 Гц · Бас", "230 Гц · Низкие", "910 Гц · Средние", "3,6 кГц · Детали", "14 кГц · Высокие"};

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(16), dp(20), dp(20));
        root.setBackgroundColor(bg);

        TextView title = text("Колонка Контроль", 27, true);
        root.addView(title);
        root.addView(text("Управление звуком и Bluetooth", 14, false));
        addGap(18);

        LinearLayout card = card();
        card.addView(text("ПОДКЛЮЧЕНИЕ", 13, true));
        card.addView(text("Подключи колонку через настройки Bluetooth телефона.", 15, false));
        Button bt = button("Открыть настройки Bluetooth");
        bt.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS)));
        card.addView(bt);
        root.addView(card);
        addGap(14);

        LinearLayout eqCard = card();
        eqCard.addView(text("СИСТЕМНЫЙ ЭКВАЛАЙЗЕР", 18, true));
        eqCard.addView(text("Пробуем обработать общий аудиовыход телефона. Работа с другими приложениями зависит от модели телефона и Android.", 13, false));
        Button enable = button("Включить эквалайзер");
        enable.setOnClickListener(v -> initEqualizer());
        eqCard.addView(enable);

        Button flat = button("Сбросить настройки");
        flat.setOnClickListener(v -> resetEq());
        eqCard.addView(flat);

        for (int i = 0; i < bands.length; i++) {
            final short band = (short)i;
            eqCard.addView(text(bands[i], 14, true));
            SeekBar seek = new SeekBar(this);
            seek.setMax(100);
            seek.setProgress(50);
            seek.setProgressTintList(android.content.res.ColorStateList.valueOf(blue));
            seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                public void onProgressChanged(SeekBar s, int p, boolean user) {
                    if (user && equalizer != null) {
                        try {
                            short range = equalizer.getBandLevelRange()[1];
                            short min = equalizer.getBandLevelRange()[0];
                            equalizer.setBandLevel(band, (short)(min + (range - min) * p / 100));
                        } catch (Exception ignored) {}
                    }
                }
                public void onStartTrackingTouch(SeekBar s) {}
                public void onStopTrackingTouch(SeekBar s) {}
            });
            eqCard.addView(seek);
        }
        root.addView(eqCard);
        addGap(14);

        LinearLayout note = card();
        note.addView(text("Важно", 17, true));
        note.addView(text("Android не гарантирует системную обработку звука для всех приложений. На некоторых телефонах эффект общего аудиовыхода недоступен или ограничен прошивкой. Это не эквалайзер, встроенный непосредственно в колонку.", 13, false));
        root.addView(note);

        setContentView(root);
    }

    private void initEqualizer() {
        try {
            if (equalizer != null) equalizer.release();
            equalizer = new Equalizer(0, 0);
            equalizer.setEnabled(true);
            Toast.makeText(this, "Эквалайзер включён, если поддерживается устройством", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Системный эквалайзер недоступен на этом телефоне", Toast.LENGTH_LONG).show();
        }
    }

    private void resetEq() {
        if (equalizer == null) {
            Toast.makeText(this, "Сначала включи эквалайзер", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            for (short i = 0; i < equalizer.getNumberOfBands(); i++) equalizer.setBandLevel(i, (short)0);
            Toast.makeText(this, "Настройки сброшены", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Не удалось сбросить настройки", Toast.LENGTH_SHORT).show();
        }
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(16), dp(16), dp(16));
        c.setBackgroundColor(panel);
        return c;
    }
    private TextView text(String s, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextColor(white); t.setTextSize(size);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(0, dp(5), 0, dp(5));
        return t;
    }
    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s); b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        return b;
    }
    private void addGap(int h) {
        View v = new View(this);
        root.addView(v, new LinearLayout.LayoutParams(1, dp(h)));
    }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override protected void onDestroy() {
        if (equalizer != null) equalizer.release();
        super.onDestroy();
    }
}
